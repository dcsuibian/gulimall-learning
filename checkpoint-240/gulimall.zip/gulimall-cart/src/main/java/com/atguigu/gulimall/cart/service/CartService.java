package com.atguigu.gulimall.cart.service;

public interface CartService {
}
