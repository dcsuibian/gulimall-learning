package com.atguigu.gulimall.order;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallOrderApplicationTests {

    @Test
    void contextLoads() {
    }

}
