package com.atguigu.gulimall.auth;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallAuthServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
