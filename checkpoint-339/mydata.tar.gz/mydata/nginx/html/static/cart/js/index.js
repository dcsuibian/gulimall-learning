$('.header-right li:nth-of-type(6)').hover(function(){
	$('.header-r-11').css('display','block')	
},function(){
	$('.header-r-11').css('display','none')
})
$('.header-right li:nth-of-type(12)').hover(function(){
	$('.header-r-2').css('display','block')	
},function(){
	$('.header-r-2').css('display','none')
})
$('.header-right li:nth-of-type(14)').hover(function(){
	$('.header-r-3').css('display','block')	
},function(){
	$('.header-r-3').css('display','none')
})
$('.header-l-2').hover(function(){
	$('.header-l-d').css('display','block')	
},function(){
	$('.header-l-d').css('display','none')
})
$('.header-r-4').hover(function(){
	$('.h-r-1').css('display','block')	
},function(){
	$('.h-r-1').css('display','none')
})
