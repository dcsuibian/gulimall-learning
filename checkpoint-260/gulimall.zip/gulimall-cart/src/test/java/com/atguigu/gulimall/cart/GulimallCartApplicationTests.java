package com.atguigu.gulimall.cart;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
