package com.atguigu.gulimall.ssoserver;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallTestSsoServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
