package com.atguigu.gulimall.ssoclient;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GulimallTestSsoClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
