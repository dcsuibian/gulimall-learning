package com.atguigu.gulimall.search.constant;

public class EsConstant {
    public static final String PRODUCT_INDEX = "product";
}
