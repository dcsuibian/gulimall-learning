package com.atguigu.gulimall.auth.vo;

import lombok.Data;

@Data
public class UserLoginVo {
    private String loginacct;
    private String password;
}
