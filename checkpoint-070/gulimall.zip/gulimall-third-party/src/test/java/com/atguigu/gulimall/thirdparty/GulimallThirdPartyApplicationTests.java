package com.atguigu.gulimall.thirdparty;

import com.aliyun.oss.OSSClient;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

@SpringBootTest
class GulimallThirdPartyApplicationTests {

	@Test
	void contextLoads() {
	}

	@Autowired
	OSSClient ossClient;
	@Test
	public void testUpload() throws FileNotFoundException {
//        String endpoint = System.getenv("ALIYUN_OSS_ENDPOINT");
//        String accessKeyId = System.getenv("ALIYUN_OSS_ACCESS_KEY_ID");
//        String accessKeySecret = System.getenv("ALIYUN_OSS_ACCESS_KEY_SECRET");
//        OSS ossClient = new OSSClientBuilder().build(endpoint, accessKeyId, accessKeySecret);
		InputStream inputStream = new FileInputStream("你的文件地址");
		ossClient.putObject(System.getenv("ALIYUN_OSS_BUCKET_NAME"), "hahaha.jpg", inputStream);
		ossClient.shutdown();
		System.out.println("上传完成...");
	}

}
