package com.atguigu.gulimall.member;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.codec.digest.Md5Crypt;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class GulimallMemberApplicationTests {

    @Test
    public void contextLoads() {
//        String s = DigestUtils.md5Hex("123456");
//
//        String s1 = Md5Crypt.md5Crypt("123456".getBytes(),"$1$qqqqqqqqq");
//        System.out.println(s1);

        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encode = passwordEncoder.encode("123456");
        boolean matches = passwordEncoder.matches("123456", "$2a$10$leKAAzYjzWIhwozbL9ABHuMEL2GXhknk4q6ysrIlIDZMxSSz.QEom");

        System.out.println(encode+"=>"+matches);
    }

}
