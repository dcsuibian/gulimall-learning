package com.atguigu.gulimall.search.constant;

public class EsConstant {
    public static final String PRODUCT_INDEX = "gulimall_product";
    public static final Integer PRODUCT_PAGESIZE = 2;
}
